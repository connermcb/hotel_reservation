package model;

import java.util.List;
import java.lang.String;

public enum RoomType {
    SINGLE,
    DOUBLE;

}
